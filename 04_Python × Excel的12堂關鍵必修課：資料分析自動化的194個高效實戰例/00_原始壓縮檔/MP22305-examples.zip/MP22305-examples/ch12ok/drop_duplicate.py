import pandas as pd
p1= pd.Series(['apple','bed','cat'], index=[0,1,2]) 
p2= pd.Series(['bed','angel','pen'], index=[1,3,5]) 
print(pd.concat([p1,p2]).drop_duplicates())
