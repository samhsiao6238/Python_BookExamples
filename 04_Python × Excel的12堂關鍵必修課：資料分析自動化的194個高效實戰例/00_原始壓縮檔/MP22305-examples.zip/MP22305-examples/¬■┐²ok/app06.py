num=8
num*=9
print(num)
num+=1
print(num)
num//=9
print(num)
num %= 5
print(num)
num -= 2
print(num)
