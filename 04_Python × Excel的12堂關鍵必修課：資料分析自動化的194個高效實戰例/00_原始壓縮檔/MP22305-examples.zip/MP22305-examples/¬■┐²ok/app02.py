name="陳大忠"
age=30
print("%s 的年齡是 %d 歲" % (name, age))
