x = 15; y = 10
print(x & y)  
print(x ^ y)   
print(x | y)  
print(~x)
