a=10;b=7;c=20
print(a/b)
print((a+b)*(c-10)/5)
