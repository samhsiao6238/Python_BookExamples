import numpy as np

num=np.array([87,98,90,95,86])

for i in range(5):
    print(num[i])
