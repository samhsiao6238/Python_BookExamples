import pandas as pd
df=pd.read_excel("import01_chi.xlsx")
print(df)
