import pandas as pd
df=pd.read_excel("import01.xlsx")
print(df)
